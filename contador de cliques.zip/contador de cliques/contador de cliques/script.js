var contador = 0;
    var botao = document.getElementById("botao");
    var contadorElemento = document.getElementById("contador");

    botao.addEventListener("click", function() {
        contador++;
        contadorElemento.textContent = contador + " clique(s)";
    });

    const input = document.getElementById("text")

input.addEventListener("keypress", (e) => {
    alert("smilinguido é legal!")
})

var botao = document.getElementById("meuBotao");

botao.addEventListener("click", function() {
    alert("Você clicou no botão!");
});

var imagem = document.getElementById("minhaImagem");

    imagem.addEventListener("mouseover", function() {
        alert("Você passou o mouse sobre a imagem!");
    });


/*-----------------------------ultimo-----------------------------------*/
var campoTexto = document.getElementById("campoTexto");
    var botaoValidar = document.getElementById("botaoValidar");

    botaoValidar.addEventListener("click", function() {
        if (campoTexto.value.trim() === "") {
            campoTexto.classList.add("error");
        } else {
            campoTexto.classList.remove("error");
        }
    });