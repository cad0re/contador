alert('oi sora, me da PD')

function exibirNome() {
    var nomeCompleto = document.getElementById("inputNome").value;
    var quantidadeLetras = nomeCompleto.replace(/\s/g, '').length;
    var mensagem = 'O Nome Completo é: "' + nomeCompleto + '".';
    alert(mensagem);
    alert('O nome tem ' + quantidadeLetras + ' letras.');
}
/* aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa */

var lampada = document.getElementById("lampada");

lampada.onclick = function () {
    if (lampada.src.endsWith("lampada-apagada.png")) {
        lampada.src = "lampada-acesa.png";
    } else {
        lampada.src = "lampada-apagada.png";
    }
};

lampada.onmouseover = function () {
    if (lampada.src.endsWith("lampada-apagada.png")) {
        lampada.src = "lampada-acesa.png";
    }
};

lampada.onmouseleave = function () {
    if (lampada.src.endsWith("lampada-acesa.png")) {
        lampada.src = "lampada-apagada.png";
    }
};

/* aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa */

function exibirSaudacao() {
    var nome = document.getElementById("nome").value;
    var sobrenome = document.getElementById("sobrenome").value;
    alert("Olá " + nome + " " + sobrenome);
}



/* aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa */

function formatarCPF(input) {
    // Remove caracteres não numéricos
    var cpf = input.value.replace(/\D/g, '');

    // Adiciona a pontuação
    cpf = cpf.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, '$1.$2.$3-$4');

    // Atualiza o valor no campo
    input.value = cpf;
}

function removerPontuacao(input) {
    // Remove caracteres não numéricos
    var cpf = input.value.replace(/\D/g, '');

    // Atualiza o valor no campo sem pontuação
    input.nextElementSibling.value = cpf;
}








function alterarCor(cor) {
    var conteudo = document.getElementById('conteudo');
    if (cor === 'verde') {
      conteudo.style.backgroundColor = 'green';
    } else if (cor === 'vermelho') {
      conteudo.style.backgroundColor = 'red';
    }
  }